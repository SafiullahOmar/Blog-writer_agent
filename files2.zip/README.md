# ArXiv Search Agent

A conversational AI agent for searching, filtering, and citing arXiv papers.

Built with:
- **`langgraph.prebuilt.create_react_agent`** — the ReAct agent loop
- **`langchain_groq.ChatGroq`** — Groq LLM (Llama 3.3 70B by default)
- **`langchain_core.tools.tool`** — 5 tool functions the agent calls

## Architecture

```
    ┌──────────────┐
    │  User Query   │   ← User Layer
    └──────┬───────┘
           │  HumanMessage
    ╔══════▼═══════════════════════════════════════╗
    ║         create_react_agent  (LangGraph)      ║
    ║                                              ║
    ║  ┌──────────┐     tool_calls?     ┌──────┐  ║
    ║  │  agent   │────── YES ────────►│ tools │  ║
    ║  │ (ChatGroq│◄─────────────────── │(Tool  │  ║
    ║  │  + tools)│     ToolMessage     │ Node) │  ║
    ║  └────┬─────┘                     └──────┘  ║
    ║       │ NO (final answer)                    ║
    ╚═══════╪══════════════════════════════════════╝
            │
    ┌───────▼──────┐
    │     END       │   ← Response to User
    └──────────────┘
```

### Workflow → LangGraph Mapping

| Diagram Layer          | LangGraph / LangChain Component              |
|------------------------|----------------------------------------------|
| **User Layer**         | `HumanMessage` input                         |
| **Chat Agent**         | `create_react_agent(model=ChatGroq, tools=…)` |
| **Intent Classifier**  | LLM reasoning (ReAct: Reason → Act)          |
| **Query Parser**       | LLM selects tool + constructs args           |
| **arXiv API**          | `search_arxiv_by_topic` / `_by_author` / `lookup_arxiv_paper` tools |
| **Results Filter**     | `filter_and_rank_results` tool               |
| **Reference Formatter**| `format_citations` tool (APA/BibTeX/IEEE/MLA)|
| **Error Handling**     | LLM observes empty ToolMessage → retries     |
| **Clarification Loop** | LLM asks user → `tools → agent` edge (cycle) |

### Key: `create_react_agent`

```python
from langgraph.prebuilt import create_react_agent
from langchain_groq import ChatGroq

llm = ChatGroq(model="llama-3.3-70b-versatile", api_key=GROQ_API_KEY)

agent = create_react_agent(
    model=llm,
    tools=ALL_TOOLS,       # 5 @tool functions
    prompt=SYSTEM_PROMPT,  # ReAct instructions
)

result = agent.invoke({"messages": [HumanMessage(content="...")]})
```

`create_react_agent` internally builds a `StateGraph` with:
- `"agent"` node — calls `ChatGroq` with tools bound
- `"tools"` node — `ToolNode` executes selected tool
- Conditional edge: agent → tools (if tool_calls) or → END
- Edge: tools → agent (loop for multi-step reasoning)

## Setup

```bash
pip install -r requirements.txt

cp .env.example .env
# Add your GROQ_API_KEY (get it at https://console.groq.com/keys)
```

### Supported Groq Models
- `llama-3.3-70b-versatile` (default — best for tool calling)
- `llama-3.1-8b-instant` (faster, lighter)
- `mixtral-8x7b-32768` (long context)
- `gemma2-9b-it`

## Usage

### CLI Chat
```bash
python -m src.main
```

### Programmatic
```python
from langchain_core.messages import HumanMessage
from src.graph import build_react_agent

agent = build_react_agent(api_key="gsk_...")

# Single query
result = agent.invoke({
    "messages": [HumanMessage(content="Find papers on diffusion models")]
})

# Multi-turn (carry forward messages)
messages = list(result["messages"])
messages.append(HumanMessage(content="Format those as BibTeX"))
result = agent.invoke({"messages": messages})
```

### With Memory (Checkpointer)
```python
from langgraph.checkpoint.memory import MemorySaver

agent = build_react_agent(api_key="gsk_...", checkpointer=MemorySaver())

# Each thread_id maintains separate conversation history
config = {"configurable": {"thread_id": "user-123"}}
result = agent.invoke(
    {"messages": [HumanMessage(content="Papers by Hinton")]},
    config=config,
)
```

## Tools

| Tool                        | Trigger                          | What it does                      |
|-----------------------------|----------------------------------|-----------------------------------|
| `search_arxiv_by_topic`     | "Find papers about X"           | Keyword search via arXiv API      |
| `search_arxiv_by_author`    | "Papers by Yann LeCun"          | Author search, optionally + topic |
| `lookup_arxiv_paper`        | "Look up 2301.07041"            | Fetch paper by arXiv ID or DOI    |
| `filter_and_rank_results`   | "Only 2024 cs.AI papers"        | Filter by year/category, re-rank  |
| `format_citations`          | "Format as BibTeX"              | APA, BibTeX, IEEE, MLA citations  |

## Project Structure

```
arxiv-agent/
├── src/
│   ├── main.py              # CLI entry point
│   ├── graph.py             # create_react_agent + ChatGroq
│   ├── config.py            # Groq API key, model settings
│   ├── tools/
│   │   └── arxiv_tools.py   # 5 @tool functions (ALL_TOOLS)
│   └── utils/
│       ├── models.py        # Paper, Author dataclasses
│       └── arxiv_client.py  # Low-level arXiv HTTP client
├── tests/
│   └── test_agent.py        # 36 unit tests
├── requirements.txt
├── .env.example
└── README.md
```

## Tests

```bash
python -m unittest tests.test_agent -v
# Runs 36 tests: tools, citations, filtering, graph compilation, mocked API, chaining
```
