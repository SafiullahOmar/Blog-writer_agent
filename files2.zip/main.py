"""ArXiv Search Agent — CLI Entry Point.

Interactive chat loop powered by:
  - langgraph.prebuilt.create_react_agent (ReAct agent graph)
  - langchain_groq.ChatGroq (Groq LLM)
  - 5 LangChain @tool functions (arXiv search, filter, format)
"""

import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from langchain_core.messages import HumanMessage
from src.graph import build_react_agent


def print_banner():
    print("""
╔═══════════════════════════════════════════════════════════════╗
║         📚 ArXiv Search Agent v3.0                            ║
║                                                               ║
║  Powered by:                                                  ║
║    • LangGraph  — create_react_agent (ReAct loop)             ║
║    • LangChain  — ChatGroq + @tool functions                  ║
║    • Groq       — Fast LLM inference                          ║
║                                                               ║
║  Examples:                                                    ║
║    • "Find papers on transformer architectures"               ║
║    • "Papers by Yann LeCun on deep learning"                  ║
║    • "Look up arxiv:2301.07041"                               ║
║    • "Format those results as BibTeX"                         ║
║    • "Show only cs.AI papers from 2024"                       ║
║                                                               ║
║  Type 'quit' to exit.                                         ║
╚═══════════════════════════════════════════════════════════════╝
""")


def extract_final_response(result: dict) -> str:
    """Extract the last AI text response from the agent output."""
    messages = result.get("messages", [])
    for msg in reversed(messages):
        if hasattr(msg, "content") and msg.content:
            # Skip tool calls and tool results
            if hasattr(msg, "tool_calls") and msg.tool_calls:
                continue
            if hasattr(msg, "tool_call_id"):
                continue
            return msg.content
    return "No response generated."


def main():
    print_banner()

    api_key = os.getenv("GROQ_API_KEY", "")
    if not api_key:
        print("⚠️  GROQ_API_KEY not set in environment.")
        api_key = input("Enter your Groq API key: ").strip()
        if not api_key:
            print("Cannot run without an API key. Exiting.")
            print("Get your key at: https://console.groq.com/keys")
            sys.exit(1)

    model = os.getenv("GROQ_MODEL", "llama-3.3-70b-versatile")
    print(f"🔧 Building ReAct agent with Groq model: {model}")

    try:
        agent = build_react_agent(api_key=api_key)
        print("✅ Agent ready!\n")
    except Exception as e:
        print(f"❌ Failed to build agent: {e}")
        sys.exit(1)

    # Multi-turn conversation: accumulate messages
    conversation: list = []

    while True:
        try:
            user_input = input("\n🔍 You: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nGoodbye!")
            break

        if not user_input:
            continue
        if user_input.lower() in ("quit", "exit", "q"):
            print("Goodbye! Happy researching. 📖")
            break

        conversation.append(HumanMessage(content=user_input))

        print("\n🤖 Thinking...", end="", flush=True)
        try:
            result = agent.invoke({"messages": conversation})

            response_text = extract_final_response(result)
            print(f"\r📄 Agent:\n\n{response_text}")

            # Carry forward full message history for multi-turn
            conversation = list(result["messages"])

        except Exception as e:
            print(f"\r⚠️  Error: {e}")


if __name__ == "__main__":
    main()
