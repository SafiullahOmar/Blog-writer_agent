"""Test suite for the ArXiv Search Agent.

Tests:
  - Tool definitions and schemas
  - Citation formatting (APA, BibTeX, IEEE, MLA)
  - Filter/ranking logic
  - create_react_agent graph compilation
  - Mocked tool invocations
  - End-to-end tool chaining
"""

import sys
import os
import json
import unittest
from unittest.mock import patch, MagicMock
from datetime import datetime, timezone

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from langchain_core.messages import HumanMessage, AIMessage

from src.tools.arxiv_tools import (
    search_arxiv_by_topic,
    search_arxiv_by_author,
    lookup_arxiv_paper,
    format_citations,
    filter_and_rank_results,
    ALL_TOOLS,
    _apa_authors,
    _ieee_authors,
    _mla_authors,
    _bibtex_key,
    _compute_relevance,
    _invert_name,
)
from src.graph import build_react_agent, SYSTEM_PROMPT


# ═══════════════════════════════════════════════════════════════════════
# Test Tool Definitions
# ═══════════════════════════════════════════════════════════════════════

class TestToolDefinitions(unittest.TestCase):
    """Verify all 5 tools are properly defined for create_react_agent."""

    def test_all_tools_count(self):
        self.assertEqual(len(ALL_TOOLS), 5)

    def test_tool_names(self):
        expected = {
            "search_arxiv_by_topic",
            "search_arxiv_by_author",
            "lookup_arxiv_paper",
            "format_citations",
            "filter_and_rank_results",
        }
        self.assertEqual({t.name for t in ALL_TOOLS}, expected)

    def test_tools_have_descriptions(self):
        for t in ALL_TOOLS:
            self.assertTrue(len(t.description) > 20, f"{t.name} missing description")

    def test_tools_have_args_schema(self):
        for t in ALL_TOOLS:
            self.assertIsNotNone(t.args_schema, f"{t.name} missing args_schema")

    def test_tools_are_langchain_tools(self):
        from langchain_core.tools import BaseTool
        for t in ALL_TOOLS:
            self.assertIsInstance(t, BaseTool)


# ═══════════════════════════════════════════════════════════════════════
# Test Citation Formatting (format_citations tool)
# ═══════════════════════════════════════════════════════════════════════

class TestCitationFormatting(unittest.TestCase):

    def setUp(self):
        self.sample = json.dumps([{
            "title": "Attention Is All You Need",
            "authors": ["Ashish Vaswani", "Noam Shazeer", "Niki Parmar"],
            "arxiv_id": "1706.03762",
            "published": "2017-06-12T00:00:00+00:00",
            "primary_category": "cs.CL",
            "doi": None,
            "journal_ref": None,
        }])

    def test_apa(self):
        r = format_citations.invoke({"papers_json": self.sample, "citation_format": "apa"})
        self.assertIn("Vaswani", r)
        self.assertIn("(2017)", r)
        self.assertIn("1706.03762", r)

    def test_bibtex(self):
        r = format_citations.invoke({"papers_json": self.sample, "citation_format": "bibtex"})
        self.assertIn("@article{", r)
        self.assertIn("eprint = {1706.03762}", r)
        self.assertIn("primaryClass = {cs.CL}", r)

    def test_ieee(self):
        r = format_citations.invoke({"papers_json": self.sample, "citation_format": "ieee"})
        self.assertIn("A. Vaswani", r)
        self.assertIn('"Attention Is All You Need,"', r)

    def test_mla(self):
        r = format_citations.invoke({"papers_json": self.sample, "citation_format": "mla"})
        self.assertIn("Vaswani", r)
        self.assertIn("et al.", r)

    def test_empty(self):
        r = format_citations.invoke({"papers_json": "[]", "citation_format": "apa"})
        self.assertIn("No papers", r)

    def test_invalid_json(self):
        r = format_citations.invoke({"papers_json": "bad", "citation_format": "apa"})
        self.assertIn("Error", r)

    def test_single_paper_wrapper(self):
        wrapped = json.dumps({"paper": {
            "title": "Test", "authors": ["A B"], "arxiv_id": "0001.00001",
            "published": "2024-01-01T00:00:00+00:00", "primary_category": "cs.AI",
            "doi": None, "journal_ref": None,
        }})
        r = format_citations.invoke({"papers_json": wrapped, "citation_format": "apa"})
        self.assertIn("B,", r)


# ═══════════════════════════════════════════════════════════════════════
# Test Name Formatting Helpers
# ═══════════════════════════════════════════════════════════════════════

class TestNameFormatting(unittest.TestCase):

    def test_invert_name(self):
        self.assertEqual(_invert_name("Yann LeCun"), "LeCun, Y.")
        self.assertEqual(_invert_name("Geoffrey E. Hinton"), "Hinton, G. E.")

    def test_apa_one(self):
        self.assertEqual(_apa_authors(["Yann LeCun"]), "LeCun, Y.")

    def test_apa_two(self):
        self.assertIn("&", _apa_authors(["Yann LeCun", "Yoshua Bengio"]))

    def test_apa_three(self):
        self.assertIn(", &", _apa_authors(["A One", "B Two", "C Three"]))

    def test_ieee_et_al(self):
        self.assertIn("et al.", _ieee_authors(["A B"] * 7))

    def test_mla_et_al(self):
        self.assertIn("et al.", _mla_authors(["A One", "B Two", "C Three"]))

    def test_bibtex_key(self):
        self.assertEqual(_bibtex_key(["Ashish Vaswani"], "2017", "Attention Is All"), "vaswani2017attention")


# ═══════════════════════════════════════════════════════════════════════
# Test Filter and Rank (filter_and_rank_results tool)
# ═══════════════════════════════════════════════════════════════════════

class TestFilterAndRank(unittest.TestCase):

    def setUp(self):
        self.papers = json.dumps({"papers": [
            {"title": "Deep Learning for NLP", "abstract": "Transformers and attention.",
             "categories": ["cs.CL"], "primary_category": "cs.CL",
             "published": "2024-06-01T00:00:00+00:00", "arxiv_id": "2406.00001", "authors": ["Alice"]},
            {"title": "Quantum Computing Basics", "abstract": "Qubits.",
             "categories": ["quant-ph"], "primary_category": "quant-ph",
             "published": "2020-01-01T00:00:00+00:00", "arxiv_id": "2001.00001", "authors": ["Bob"]},
            {"title": "Attention Mechanisms in Vision", "abstract": "Self-attention for images.",
             "categories": ["cs.CV"], "primary_category": "cs.CV",
             "published": "2023-09-01T00:00:00+00:00", "arxiv_id": "2309.00001", "authors": ["Charlie"]},
        ]})

    def test_keyword_ranking(self):
        r = json.loads(filter_and_rank_results.invoke({
            "papers_json": self.papers, "keywords": "attention NLP", "sort_by": "relevance",
        }))
        # Papers with attention/NLP should rank above quantum
        self.assertNotEqual(r["papers"][-1]["title"], "Deep Learning for NLP")

    def test_year_filter(self):
        r = json.loads(filter_and_rank_results.invoke({
            "papers_json": self.papers, "min_year": 2023,
        }))
        self.assertEqual(r["total_after_filter"], 2)

    def test_category_filter(self):
        r = json.loads(filter_and_rank_results.invoke({
            "papers_json": self.papers, "categories": "cs.CL",
        }))
        self.assertEqual(r["total_after_filter"], 1)
        self.assertEqual(r["papers"][0]["title"], "Deep Learning for NLP")

    def test_date_sort(self):
        r = json.loads(filter_and_rank_results.invoke({
            "papers_json": self.papers, "sort_by": "date",
        }))
        dates = [p["published"] for p in r["papers"]]
        self.assertEqual(dates, sorted(dates, reverse=True))


# ═══════════════════════════════════════════════════════════════════════
# Test Relevance Scoring
# ═══════════════════════════════════════════════════════════════════════

class TestRelevanceScoring(unittest.TestCase):

    def test_title_beats_abstract(self):
        p1 = {"title": "deep learning methods", "abstract": "text", "published": "2020-01-01T00:00:00+00:00"}
        p2 = {"title": "some paper", "abstract": "about deep learning", "published": "2020-01-01T00:00:00+00:00"}
        self.assertGreater(
            _compute_relevance(p1, ["deep", "learning"]),
            _compute_relevance(p2, ["deep", "learning"]),
        )

    def test_no_match_zero(self):
        p = {"title": "quantum", "abstract": "qubits", "published": "2020-01-01T00:00:00+00:00"}
        self.assertEqual(_compute_relevance(p, ["biology"]), 0.0)


# ═══════════════════════════════════════════════════════════════════════
# Test create_react_agent Graph
# ═══════════════════════════════════════════════════════════════════════

class TestReactAgentGraph(unittest.TestCase):
    """Test that create_react_agent compiles correctly."""

    def test_system_prompt(self):
        self.assertIn("arXiv", SYSTEM_PROMPT)
        self.assertIn("search_arxiv_by_topic", SYSTEM_PROMPT)
        self.assertIn("ReAct", SYSTEM_PROMPT)

    def test_graph_compiles_with_groq(self):
        """Verify create_react_agent compiles (doesn't need a valid key to compile)."""
        try:
            agent = build_react_agent(api_key="test-key-for-compilation-only")
            self.assertIsNotNone(agent)
            self.assertTrue(hasattr(agent, "invoke"))
            self.assertTrue(hasattr(agent, "stream"))
        except Exception as e:
            if "api" not in str(e).lower() and "key" not in str(e).lower():
                raise

    def test_graph_has_expected_structure(self):
        """Verify the compiled graph has agent and tools nodes."""
        try:
            agent = build_react_agent(api_key="test-key")
            # The compiled graph should have our nodes from create_react_agent
            graph_dict = agent.get_graph().to_json()
            # create_react_agent generates 'agent' and 'tools' nodes
            self.assertIsNotNone(graph_dict)
        except Exception:
            pass  # OK if API key validation prevents this

    def test_missing_key_raises(self):
        """Must raise if no API key provided."""
        # Clear env
        original = os.environ.get("GROQ_API_KEY")
        os.environ.pop("GROQ_API_KEY", None)
        try:
            with self.assertRaises(ValueError):
                build_react_agent(api_key="")
        finally:
            if original:
                os.environ["GROQ_API_KEY"] = original


# ═══════════════════════════════════════════════════════════════════════
# Test Mocked Tool Invocations
# ═══════════════════════════════════════════════════════════════════════

class TestToolInvocationMocked(unittest.TestCase):
    """Test tools with mocked arXiv API."""

    @patch("src.tools.arxiv_tools.ArxivClient.search")
    def test_topic_search(self, mock_search):
        from src.utils.models import Paper, Author
        mock_search.return_value = ([
            Paper(arxiv_id="2301.00001", title="Test Transformer Paper",
                  authors=[Author(name="Alice")], abstract="About transformers.",
                  categories=["cs.CL"], primary_category="cs.CL"),
        ], 1)

        r = json.loads(search_arxiv_by_topic.invoke({"keywords": "transformer"}))
        self.assertEqual(r["returned"], 1)
        self.assertEqual(r["papers"][0]["title"], "Test Transformer Paper")
        mock_search.assert_called_once()

    @patch("src.tools.arxiv_tools.ArxivClient.search")
    def test_author_search(self, mock_search):
        from src.utils.models import Paper, Author
        mock_search.return_value = ([
            Paper(arxiv_id="1409.1556", title="Deep Learning",
                  authors=[Author(name="Yann LeCun"), Author(name="Yoshua Bengio")]),
        ], 1)

        r = json.loads(search_arxiv_by_author.invoke({"author_name": "Yann LeCun"}))
        self.assertEqual(r["returned"], 1)
        self.assertIn("Yann LeCun", r["papers"][0]["authors"])

    @patch("src.tools.arxiv_tools.ArxivClient.search")
    def test_lookup_found(self, mock_search):
        from src.utils.models import Paper, Author
        mock_search.return_value = ([
            Paper(arxiv_id="2301.07041", title="Some Paper", authors=[Author(name="Bob")]),
        ], 1)

        r = json.loads(lookup_arxiv_paper.invoke({"paper_id": "2301.07041"}))
        self.assertIsNotNone(r["paper"])
        self.assertEqual(r["paper"]["arxiv_id"], "2301.07041")

    @patch("src.tools.arxiv_tools.ArxivClient.search")
    def test_lookup_not_found(self, mock_search):
        mock_search.return_value = ([], 0)
        r = json.loads(lookup_arxiv_paper.invoke({"paper_id": "9999.99999"}))
        self.assertIsNone(r["paper"])
        self.assertIn("No paper found", r["error"])

    @patch("src.tools.arxiv_tools.ArxivClient.search")
    def test_lookup_strips_prefix(self, mock_search):
        from src.utils.models import Paper, Author
        mock_search.return_value = ([
            Paper(arxiv_id="2301.07041", title="X", authors=[Author(name="A")]),
        ], 1)
        lookup_arxiv_paper.invoke({"paper_id": "arxiv:2301.07041"})
        # Should have called with stripped ID
        call_kwargs = mock_search.call_args
        self.assertIn("2301.07041", str(call_kwargs))

    @patch("src.tools.arxiv_tools.ArxivClient.search")
    def test_api_error(self, mock_search):
        mock_search.side_effect = ConnectionError("Network error")
        r = json.loads(search_arxiv_by_topic.invoke({"keywords": "test"}))
        self.assertIn("error", r)
        self.assertEqual(r["papers"], [])


# ═══════════════════════════════════════════════════════════════════════
# Test Tool Chaining: search → filter → format
# ═══════════════════════════════════════════════════════════════════════

class TestToolChaining(unittest.TestCase):

    @patch("src.tools.arxiv_tools.ArxivClient.search")
    def test_full_chain(self, mock_search):
        from src.utils.models import Paper, Author

        mock_search.return_value = ([
            Paper(arxiv_id="1", title="Deep NLP", authors=[Author(name="A One")],
                  abstract="Transformers for NLP", categories=["cs.CL"],
                  primary_category="cs.CL",
                  published=datetime(2024, 1, 1, tzinfo=timezone.utc)),
            Paper(arxiv_id="2", title="Quantum Stuff", authors=[Author(name="B Two")],
                  abstract="Qubits", categories=["quant-ph"],
                  primary_category="quant-ph",
                  published=datetime(2020, 1, 1, tzinfo=timezone.utc)),
        ], 2)

        # Step 1: Search
        search_result = search_arxiv_by_topic.invoke({"keywords": "NLP transformers"})

        # Step 2: Filter to cs.CL only
        filtered = filter_and_rank_results.invoke({
            "papers_json": search_result,
            "categories": "cs.CL",
            "keywords": "NLP transformers",
            "sort_by": "relevance",
        })
        fd = json.loads(filtered)
        self.assertEqual(fd["total_after_filter"], 1)
        self.assertEqual(fd["papers"][0]["title"], "Deep NLP")

        # Step 3: Format as BibTeX
        citations = format_citations.invoke({
            "papers_json": filtered,
            "citation_format": "bibtex",
        })
        self.assertIn("@article{", citations)
        self.assertIn("Deep NLP", citations)


if __name__ == "__main__":
    unittest.main()
