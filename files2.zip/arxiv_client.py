"""arXiv API HTTP client.

Low-level client for HTTP communication with arXiv's Atom API.
Used by the LangChain tools to fetch and parse papers.
"""

import time
from datetime import datetime
from typing import Optional

import feedparser
import requests

from .models import Paper, Author


class ArxivClient:
    """Low-level arXiv API client."""

    BASE_URL = "http://export.arxiv.org/api/query"
    _last_request_time: float = 0.0
    _rate_limit_delay: float = 3.0

    @classmethod
    def search(
        cls,
        search_query: str = "",
        id_list: str = "",
        start: int = 0,
        max_results: int = 10,
        sort_by: str = "relevance",
        sort_order: str = "descending",
    ) -> tuple[list[Paper], int]:
        """Execute search against arXiv API. Returns (papers, total_count)."""
        cls._respect_rate_limit()

        params = {"start": start, "max_results": max_results}
        if search_query:
            params["search_query"] = search_query
        if id_list:
            params["id_list"] = id_list
        if sort_by and sort_by != "relevance":
            params["sortBy"] = sort_by
            params["sortOrder"] = sort_order

        try:
            resp = requests.get(
                cls.BASE_URL, params=params, timeout=30,
                headers={"User-Agent": "ArxivSearchAgent/1.0"},
            )
            resp.raise_for_status()
        except requests.RequestException as e:
            raise ConnectionError(f"arXiv API request failed: {e}") from e
        finally:
            cls._last_request_time = time.time()

        feed = feedparser.parse(resp.text)
        papers = [cls._parse_entry(entry) for entry in feed.entries]
        total = int(feed.feed.get("opensearch_totalresults", len(papers)))
        return papers, total

    @classmethod
    def _parse_entry(cls, entry: dict) -> Paper:
        entry_id = entry.get("id", "")
        arxiv_id = entry_id.split("/abs/")[-1] if "/abs/" in entry_id else entry_id

        authors = [
            Author(name=ad.get("name", "Unknown"), affiliation=ad.get("arxiv_affiliation"))
            for ad in entry.get("authors", [])
        ]

        tags = entry.get("tags", [])
        categories = [t.get("term", "") for t in tags if t.get("term")]
        primary_category = entry.get("arxiv_primary_category", {}).get("term", "")

        pdf_url, abs_url = "", ""
        for link in entry.get("links", []):
            if link.get("type") == "application/pdf":
                pdf_url = link.get("href", "")
            elif link.get("rel") == "alternate":
                abs_url = link.get("href", "")

        return Paper(
            arxiv_id=arxiv_id,
            title=" ".join(entry.get("title", "Untitled").split()),
            authors=authors,
            abstract=" ".join(entry.get("summary", "").split()),
            categories=categories,
            primary_category=primary_category,
            published=cls._parse_date(entry.get("published")),
            updated=cls._parse_date(entry.get("updated")),
            doi=entry.get("arxiv_doi"),
            pdf_url=pdf_url,
            abs_url=abs_url,
            comment=entry.get("arxiv_comment"),
            journal_ref=entry.get("arxiv_journal_ref"),
        )

    @staticmethod
    def _parse_date(date_str: Optional[str]) -> Optional[datetime]:
        if not date_str:
            return None
        try:
            return datetime.fromisoformat(date_str.replace("Z", "+00:00"))
        except (ValueError, AttributeError):
            return None

    @classmethod
    def _respect_rate_limit(cls):
        if cls._last_request_time > 0:
            elapsed = time.time() - cls._last_request_time
            if elapsed < cls._rate_limit_delay:
                time.sleep(cls._rate_limit_delay - elapsed)
