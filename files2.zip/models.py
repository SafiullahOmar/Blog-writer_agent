"""Data models used across the ArXiv Search Agent."""

from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional


@dataclass
class Author:
    """Represents a paper author."""
    name: str
    affiliation: Optional[str] = None


@dataclass
class Paper:
    """Represents a single arXiv paper."""
    arxiv_id: str
    title: str
    authors: list[Author] = field(default_factory=list)
    abstract: str = ""
    categories: list[str] = field(default_factory=list)
    primary_category: str = ""
    published: Optional[datetime] = None
    updated: Optional[datetime] = None
    doi: Optional[str] = None
    pdf_url: str = ""
    abs_url: str = ""
    comment: Optional[str] = None
    journal_ref: Optional[str] = None

    @property
    def year(self) -> int:
        return self.published.year if self.published else 0

    @property
    def author_names(self) -> list[str]:
        return [a.name for a in self.authors]

    def to_dict(self) -> dict:
        """Serialize for passing through LangGraph state."""
        return {
            "arxiv_id": self.arxiv_id,
            "title": self.title,
            "authors": [a.name for a in self.authors],
            "abstract": self.abstract[:500],
            "categories": self.categories,
            "primary_category": self.primary_category,
            "published": self.published.isoformat() if self.published else None,
            "doi": self.doi,
            "pdf_url": self.pdf_url,
            "abs_url": self.abs_url or f"https://arxiv.org/abs/{self.arxiv_id}",
            "journal_ref": self.journal_ref,
        }
