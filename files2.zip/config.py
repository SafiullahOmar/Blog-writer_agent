"""Configuration settings for the ArXiv Search Agent."""

import os
from dotenv import load_dotenv

load_dotenv()


class Settings:
    """Central configuration."""

    # Groq LLM
    GROQ_API_KEY = os.getenv("GROQ_API_KEY", "")
    GROQ_MODEL = os.getenv("GROQ_MODEL", "llama-3.3-70b-versatile")
    MODEL_TEMPERATURE = 0.0
    MODEL_MAX_TOKENS = 4096

    # arXiv API
    ARXIV_BASE_URL = "http://export.arxiv.org/api/query"
    MAX_RESULTS_DEFAULT = 10
    MAX_RESULTS_LIMIT = 50
    REQUEST_TIMEOUT = 30
    RATE_LIMIT_DELAY = float(os.getenv("ARXIV_RATE_LIMIT_DELAY", "3.0"))

    # arXiv categories reference
    ARXIV_CATEGORIES = {
        "cs.AI": "Artificial Intelligence",
        "cs.CL": "Computation and Language",
        "cs.CV": "Computer Vision",
        "cs.LG": "Machine Learning",
        "cs.NE": "Neural and Evolutionary Computing",
        "cs.RO": "Robotics",
        "stat.ML": "Machine Learning (Statistics)",
        "math": "Mathematics",
        "physics": "Physics",
        "q-bio": "Quantitative Biology",
        "q-fin": "Quantitative Finance",
        "econ": "Economics",
    }

    # Output
    DEFAULT_CITATION_FORMAT = "apa"
    SUPPORTED_FORMATS = ["apa", "bibtex", "ieee", "mla"]


settings = Settings()
