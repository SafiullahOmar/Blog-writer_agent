"""LangGraph Workflow — ArXiv Search Agent.

Uses `create_react_agent` from `langgraph.prebuilt` with `ChatGroq`
to build a ReAct agent that loops: LLM → Tool → LLM → ... → END.

Architecture (mapping workflow diagram to LangGraph):
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

    ┌──────────────┐
    │  User Query   │   ← User Layer (input message)
    └──────┬───────┘
           │
    ╔══════▼═══════╗
    ║  ReAct Agent  ║   ← Agent Layer (ChatGroq with tools)
    ║ (LangGraph    ║     • Intent Classification → LLM reasoning
    ║  prebuilt)    ║     • Query Parsing → LLM selects tool + args
    ╚══════╤═══════╝     • Error Handling → LLM observes results & retries
           │
      tool_calls?
      ┌────┴────┐
      │  YES    │ NO
      ▼         ▼
    ┌─────┐  ┌─────┐
    │Tools│  │ END │   ← Output Layer (final response)
    └──┬──┘  └─────┘
       │
       │  ToolNode executes:
       │  • search_arxiv_by_topic    ← Tool Layer (arXiv API)
       │  • search_arxiv_by_author   ← Tool Layer (arXiv API)
       │  • lookup_arxiv_paper       ← Tool Layer (arXiv API)
       │  • filter_and_rank_results  ← Results Filter & Ranker
       │  • format_citations         ← Output Layer (APA/BibTeX/IEEE/MLA)
       │
       └──► back to ReAct Agent (loop)
            ↑ Clarification Loop / Retry with refined query

`create_react_agent` builds the full StateGraph internally:
  - Adds an "agent" node (LLM call)
  - Adds a "tools" node (ToolNode)
  - Adds conditional edge: agent → tools (if tool_calls) or agent → END
  - Adds edge: tools → agent (loop back)
"""

from langchain_groq import ChatGroq
from langgraph.prebuilt import create_react_agent

from .tools.arxiv_tools import ALL_TOOLS
from .config import settings


# ═══════════════════════════════════════════════════════════════════════
# System Prompt — drives the ReAct agent's behavior
# ═══════════════════════════════════════════════════════════════════════

SYSTEM_PROMPT = """You are an expert academic research assistant specializing in arXiv paper search.
Your job is to help users find, filter, and cite academic papers from arXiv.

## Your Workflow (ReAct: Reason → Act → Observe → Repeat)

1. **Reason** about the user's intent:
   - Specific paper by DOI or arXiv ID → use `lookup_arxiv_paper`
   - Papers by a specific author → use `search_arxiv_by_author`
   - Papers on a topic/keywords → use `search_arxiv_by_topic`
   - Filter or re-rank existing results → use `filter_and_rank_results`
   - Generate citations → use `format_citations`

2. **Act** by calling the appropriate tool with well-formed arguments.

3. **Observe** the tool results:
   - If results are good → present them to the user clearly
   - If results are empty → **retry** with broader keywords or different query
   - If still empty after 2 retries → ask the user to clarify their query

4. **Present results** with:
   - Paper title, authors, year, category
   - Brief abstract summary
   - Link: https://arxiv.org/abs/<arxiv_id>
   - Citation if requested

## Important Rules
- ALWAYS use tools to search. NEVER fabricate paper titles, authors, or IDs.
- If a search returns no results, try broadening the query before asking the user.
- You can chain tools: search → filter → format citations.
- Default citation format is APA unless the user specifies otherwise.
- Number papers clearly when presenting multiple results.
- Be conversational and helpful.

## arXiv Categories
Common: cs.AI, cs.CL (NLP), cs.CV (Vision), cs.LG (ML), cs.NE, stat.ML, math.*, physics.*
"""


# ═══════════════════════════════════════════════════════════════════════
# Build the ReAct Agent Graph
# ═══════════════════════════════════════════════════════════════════════

def build_react_agent(
    api_key: str = "",
    model_name: str = "",
    checkpointer=None,
):
    """Build the compiled ReAct agent graph using `create_react_agent`.

    This uses LangGraph's prebuilt `create_react_agent()` which internally
    creates a StateGraph with:
      - "agent" node:  ChatGroq LLM call (with tools bound)
      - "tools" node:  ToolNode executing whichever tool the LLM selected
      - Conditional edge: agent → tools (if tool_calls) or → END
      - Edge: tools → agent (loop back for multi-step reasoning)

    Args:
        api_key: Groq API key. Falls back to GROQ_API_KEY env var.
        model_name: Groq model name. Falls back to config default.
        checkpointer: Optional LangGraph checkpointer for conversation memory.

    Returns:
        A compiled CompiledStateGraph (the ReAct agent).
    """
    _api_key = api_key or settings.GROQ_API_KEY
    _model = model_name or settings.GROQ_MODEL

    if not _api_key:
        raise ValueError(
            "GROQ_API_KEY is required. Set it in .env or pass it directly.\n"
            "Get your key at: https://console.groq.com/keys"
        )

    # ── Create the Groq LLM ─────────────────────────────────────────
    llm = ChatGroq(
        model=_model,
        api_key=_api_key,
        temperature=settings.MODEL_TEMPERATURE,
        max_tokens=settings.MODEL_MAX_TOKENS,
    )

    # ── Build ReAct Agent via langgraph.prebuilt.create_react_agent ──
    #
    # This is the core function from LangGraph that wires up the full
    # ReAct loop: LLM ↔ Tools with conditional routing.
    #
    # Under the hood it creates:
    #   StateGraph(AgentState)
    #     .add_node("agent", call_model)
    #     .add_node("tools", ToolNode(tools))
    #     .add_edge(START, "agent")
    #     .add_conditional_edges("agent", should_continue, {"tools", END})
    #     .add_edge("tools", "agent")
    #     .compile()

    react_agent = create_react_agent(
        model=llm,
        tools=ALL_TOOLS,
        prompt=SYSTEM_PROMPT,
        checkpointer=checkpointer,
        name="arxiv_search_agent",
    )

    return react_agent
