"""Tests — run with: python test_agent.py"""

import sys
import os
import json
import unittest
from unittest.mock import patch
from datetime import datetime, timezone

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from tools import (
    search_arxiv_by_topic, search_arxiv_by_author, lookup_arxiv_paper,
    format_citations, filter_and_rank_results, ALL_TOOLS,
    _apa_authors, _ieee_authors, _mla_authors, _bibtex_key,
    _compute_relevance, _invert_name,
)
from graph import build_react_agent, SYSTEM_PROMPT


class TestToolDefinitions(unittest.TestCase):
    def test_count(self):
        self.assertEqual(len(ALL_TOOLS), 5)

    def test_names(self):
        expected = {"search_arxiv_by_topic", "search_arxiv_by_author",
                    "lookup_arxiv_paper", "format_citations", "filter_and_rank_results"}
        self.assertEqual({t.name for t in ALL_TOOLS}, expected)

    def test_are_langchain_tools(self):
        from langchain_core.tools import BaseTool
        for t in ALL_TOOLS:
            self.assertIsInstance(t, BaseTool)


class TestCitations(unittest.TestCase):
    def setUp(self):
        self.sample = json.dumps([{
            "title": "Attention Is All You Need",
            "authors": ["Ashish Vaswani", "Noam Shazeer", "Niki Parmar"],
            "arxiv_id": "1706.03762",
            "published": "2017-06-12T00:00:00+00:00",
            "primary_category": "cs.CL", "doi": None, "journal_ref": None,
        }])

    def test_apa(self):
        r = format_citations.invoke({"papers_json": self.sample, "citation_format": "apa"})
        self.assertIn("Vaswani", r)
        self.assertIn("(2017)", r)

    def test_bibtex(self):
        r = format_citations.invoke({"papers_json": self.sample, "citation_format": "bibtex"})
        self.assertIn("@article{", r)

    def test_ieee(self):
        r = format_citations.invoke({"papers_json": self.sample, "citation_format": "ieee"})
        self.assertIn("A. Vaswani", r)

    def test_mla(self):
        r = format_citations.invoke({"papers_json": self.sample, "citation_format": "mla"})
        self.assertIn("et al.", r)

    def test_empty(self):
        self.assertIn("No papers", format_citations.invoke({"papers_json": "[]", "citation_format": "apa"}))


class TestFilter(unittest.TestCase):
    def setUp(self):
        self.papers = json.dumps({"papers": [
            {"title": "Deep NLP", "abstract": "Transformers.", "categories": ["cs.CL"],
             "primary_category": "cs.CL", "published": "2024-06-01T00:00:00+00:00",
             "arxiv_id": "2406.00001", "authors": ["A"]},
            {"title": "Quantum", "abstract": "Qubits.", "categories": ["quant-ph"],
             "primary_category": "quant-ph", "published": "2020-01-01T00:00:00+00:00",
             "arxiv_id": "2001.00001", "authors": ["B"]},
        ]})

    def test_year(self):
        r = json.loads(filter_and_rank_results.invoke({"papers_json": self.papers, "min_year": 2023}))
        self.assertEqual(r["total_after_filter"], 1)

    def test_category(self):
        r = json.loads(filter_and_rank_results.invoke({"papers_json": self.papers, "categories": "cs.CL"}))
        self.assertEqual(r["total_after_filter"], 1)


class TestGraph(unittest.TestCase):
    def test_prompt(self):
        self.assertIn("ReAct", SYSTEM_PROMPT)

    def test_compiles(self):
        try:
            agent = build_react_agent(api_key="test-key")
            self.assertTrue(hasattr(agent, "invoke"))
        except Exception as e:
            if "api" not in str(e).lower() and "key" not in str(e).lower():
                raise

    def test_missing_key(self):
        orig = os.environ.pop("GROQ_API_KEY", None)
        try:
            with self.assertRaises(ValueError):
                build_react_agent(api_key="")
        finally:
            if orig:
                os.environ["GROQ_API_KEY"] = orig


class TestMocked(unittest.TestCase):
    @patch("tools.ArxivClient.search")
    def test_topic(self, mock):
        from models import Paper, Author
        mock.return_value = ([Paper(arxiv_id="1", title="Test", authors=[Author(name="A")],
                                    categories=["cs.CL"], primary_category="cs.CL")], 1)
        r = json.loads(search_arxiv_by_topic.invoke({"keywords": "transformer"}))
        self.assertEqual(r["returned"], 1)

    @patch("tools.ArxivClient.search")
    def test_author(self, mock):
        from models import Paper, Author
        mock.return_value = ([Paper(arxiv_id="2", title="DL", authors=[Author(name="LeCun")])], 1)
        r = json.loads(search_arxiv_by_author.invoke({"author_name": "LeCun"}))
        self.assertEqual(r["returned"], 1)

    @patch("tools.ArxivClient.search")
    def test_lookup(self, mock):
        from models import Paper, Author
        mock.return_value = ([Paper(arxiv_id="2301.07041", title="X", authors=[Author(name="A")])], 1)
        r = json.loads(lookup_arxiv_paper.invoke({"paper_id": "2301.07041"}))
        self.assertIsNotNone(r["paper"])

    @patch("tools.ArxivClient.search")
    def test_not_found(self, mock):
        mock.return_value = ([], 0)
        r = json.loads(lookup_arxiv_paper.invoke({"paper_id": "9999.99999"}))
        self.assertIsNone(r["paper"])

    @patch("tools.ArxivClient.search")
    def test_chain(self, mock):
        from models import Paper, Author
        mock.return_value = ([
            Paper(arxiv_id="1", title="Deep NLP", authors=[Author(name="A")],
                  categories=["cs.CL"], primary_category="cs.CL",
                  published=datetime(2024, 1, 1, tzinfo=timezone.utc)),
        ], 1)
        s = search_arxiv_by_topic.invoke({"keywords": "NLP"})
        f = filter_and_rank_results.invoke({"papers_json": s, "categories": "cs.CL"})
        c = format_citations.invoke({"papers_json": f, "citation_format": "bibtex"})
        self.assertIn("@article{", c)


if __name__ == "__main__":
    unittest.main()
