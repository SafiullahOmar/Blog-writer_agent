"""LangChain Tools — passed to create_react_agent().

5 @tool functions:
  1. search_arxiv_by_topic
  2. search_arxiv_by_author
  3. lookup_arxiv_paper
  4. filter_and_rank_results
  5. format_citations
"""

import json
import re
from datetime import datetime, timezone
from typing import Optional

from langchain_core.tools import tool

from arxiv_client import ArxivClient


# ─────────────────────────────────────────────────────────────────────
# TOOL 1: Search by Topic
# ─────────────────────────────────────────────────────────────────────

@tool
def search_arxiv_by_topic(
    keywords: str,
    category: Optional[str] = None,
    max_results: int = 10,
    sort_by: str = "relevance",
) -> str:
    """Search arXiv for papers matching topic keywords.

    Use this when the user wants to find papers about a specific topic,
    subject area, or research question.

    Args:
        keywords: Space-separated search keywords (e.g. "transformer attention mechanism NLP").
        category: Optional arXiv category filter (e.g. "cs.AI", "cs.CL", "stat.ML").
        max_results: Number of results to return (1-50, default 10).
        sort_by: Sort order — "relevance", "lastUpdatedDate", or "submittedDate".

    Returns:
        JSON string with paper metadata.
    """
    max_results = min(max(1, max_results), 50)
    words = keywords.strip().split()
    if not words:
        return json.dumps({"error": "No keywords provided", "papers": []})

    parts = [f"ti:{words[0]}"]
    for w in words[1:5]:
        parts.append(f"all:{w}")
    query = " AND ".join(parts)
    if category:
        query = f"({query}) AND cat:{category}"

    try:
        papers, total = ArxivClient.search(
            search_query=query, max_results=max_results, sort_by=sort_by,
        )
    except Exception as e:
        return json.dumps({"error": str(e), "papers": []})

    return json.dumps({
        "total_results": total,
        "returned": len(papers),
        "query_used": query,
        "papers": [p.to_dict() for p in papers],
    }, default=str)


# ─────────────────────────────────────────────────────────────────────
# TOOL 2: Search by Author
# ─────────────────────────────────────────────────────────────────────

@tool
def search_arxiv_by_author(
    author_name: str,
    topic_keywords: Optional[str] = None,
    category: Optional[str] = None,
    max_results: int = 10,
) -> str:
    """Search arXiv for papers by a specific author.

    Use this when the user wants papers written by a particular researcher.

    Args:
        author_name: Full name of the author (e.g. "Yann LeCun", "Geoffrey Hinton").
        topic_keywords: Optional topic keywords to narrow results (e.g. "deep learning").
        category: Optional arXiv category filter (e.g. "cs.LG").
        max_results: Number of results to return (1-50, default 10).

    Returns:
        JSON string with paper metadata.
    """
    max_results = min(max(1, max_results), 50)
    parts = [f'au:"{author_name}"']
    if topic_keywords:
        for kw in topic_keywords.strip().split()[:3]:
            parts.append(f"all:{kw}")
    if category:
        parts.append(f"cat:{category}")
    query = " AND ".join(parts)

    try:
        papers, total = ArxivClient.search(
            search_query=query, max_results=max_results,
            sort_by="submittedDate", sort_order="descending",
        )
    except Exception as e:
        return json.dumps({"error": str(e), "papers": []})

    return json.dumps({
        "total_results": total,
        "returned": len(papers),
        "query_used": query,
        "papers": [p.to_dict() for p in papers],
    }, default=str)


# ─────────────────────────────────────────────────────────────────────
# TOOL 3: Lookup by ID / DOI
# ─────────────────────────────────────────────────────────────────────

@tool
def lookup_arxiv_paper(paper_id: str) -> str:
    """Look up a specific arXiv paper by its arXiv ID or DOI.

    Use this when the user provides a specific paper identifier.

    Args:
        paper_id: arXiv ID (e.g. "2301.07041") or DOI (e.g. "10.1038/nature12373").

    Returns:
        JSON string with the paper's full metadata.
    """
    paper_id = paper_id.strip()
    paper_id = re.sub(r"^(arxiv:|arXiv:)", "", paper_id)
    paper_id = re.sub(r"^https?://arxiv\.org/abs/", "", paper_id)

    is_doi = paper_id.startswith("10.")
    try:
        if is_doi:
            papers, total = ArxivClient.search(search_query=f'doi:"{paper_id}"', max_results=5)
        else:
            papers, total = ArxivClient.search(id_list=paper_id, max_results=1)
    except Exception as e:
        return json.dumps({"error": str(e), "paper": None})

    if not papers:
        return json.dumps({
            "error": f"No paper found with identifier '{paper_id}'",
            "paper": None,
            "suggestion": "Check the ID/DOI. arXiv IDs look like '2301.07041', DOIs like '10.xxxx/...'",
        })

    return json.dumps({"paper": papers[0].to_dict(), "total_results": total}, default=str)


# ─────────────────────────────────────────────────────────────────────
# TOOL 4: Filter and Rank Results
# ─────────────────────────────────────────────────────────────────────

@tool
def filter_and_rank_results(
    papers_json: str,
    keywords: Optional[str] = None,
    min_year: Optional[int] = None,
    max_year: Optional[int] = None,
    categories: Optional[str] = None,
    sort_by: str = "relevance",
) -> str:
    """Filter and re-rank search results by relevance, date, or category.

    Use this to narrow down or re-sort papers returned from a previous search.

    Args:
        papers_json: JSON string containing papers (from a search tool result).
        keywords: Space-separated keywords to score relevance against.
        min_year: Minimum publication year (inclusive).
        max_year: Maximum publication year (inclusive).
        categories: Comma-separated arXiv categories to keep (e.g. "cs.AI,cs.LG").
        sort_by: "relevance" (keyword match), "date", or "title".

    Returns:
        JSON string with filtered/ranked papers.
    """
    try:
        data = json.loads(papers_json)
        papers = data.get("papers", data) if isinstance(data, dict) else data
        if not isinstance(papers, list):
            return json.dumps({"error": "Invalid format", "papers": []})
    except json.JSONDecodeError:
        return json.dumps({"error": "Invalid JSON", "papers": []})

    if min_year:
        papers = [p for p in papers if _get_year(p) >= min_year]
    if max_year:
        papers = [p for p in papers if _get_year(p) <= max_year]
    if categories:
        cat_set = set(c.strip().lower() for c in categories.split(","))
        papers = [
            p for p in papers
            if any(c.lower() in cat_set for c in p.get("categories", []))
            or p.get("primary_category", "").lower() in cat_set
        ]
    if keywords:
        kw_list = keywords.lower().split()
        for p in papers:
            p["_score"] = _compute_relevance(p, kw_list)

    if sort_by == "relevance" and keywords:
        papers.sort(key=lambda p: p.get("_score", 0), reverse=True)
    elif sort_by == "date":
        papers.sort(key=lambda p: p.get("published", ""), reverse=True)
    elif sort_by == "title":
        papers.sort(key=lambda p: p.get("title", "").lower())

    for p in papers:
        p.pop("_score", None)

    return json.dumps({"total_after_filter": len(papers), "papers": papers}, default=str)


# ─────────────────────────────────────────────────────────────────────
# TOOL 5: Format Citations
# ─────────────────────────────────────────────────────────────────────

@tool
def format_citations(
    papers_json: str,
    citation_format: str = "apa",
) -> str:
    """Format paper metadata into standard academic citations.

    Use this after retrieving papers to generate properly formatted references.

    Args:
        papers_json: JSON string with paper list (from search results).
        citation_format: Style — "apa", "bibtex", "ieee", or "mla".

    Returns:
        Formatted citations as a string.
    """
    try:
        papers = json.loads(papers_json)
        if isinstance(papers, dict):
            if "paper" in papers and papers["paper"]:
                papers = [papers["paper"]]
            elif "papers" in papers:
                papers = papers["papers"]
            else:
                papers = [papers]
    except json.JSONDecodeError:
        return "Error: Invalid JSON input for papers."

    if not papers:
        return "No papers to format."

    fmt = citation_format.lower().strip()
    citations = []

    for i, p in enumerate(papers, 1):
        if not isinstance(p, dict):
            continue
        title = p.get("title", "Untitled")
        authors = p.get("authors", ["Unknown"])
        arxiv_id = p.get("arxiv_id", "")
        year = _extract_year(p.get("published", ""))
        doi = p.get("doi")
        journal_ref = p.get("journal_ref")
        primary_cat = p.get("primary_category", "")

        if fmt == "bibtex":
            key = _bibtex_key(authors, year, title)
            author_str = " and ".join(authors) if isinstance(authors, list) else str(authors)
            lines = [
                f"@article{{{key},",
                f"  author = {{{author_str}}},",
                f"  title = {{{title}}},",
                f"  year = {{{year}}},",
                f"  eprint = {{{arxiv_id}}},",
                f"  archivePrefix = {{arXiv}},",
            ]
            if primary_cat:
                lines.append(f"  primaryClass = {{{primary_cat}}},")
            if doi:
                lines.append(f"  doi = {{{doi}}},")
            if journal_ref:
                lines.append(f"  journal = {{{journal_ref}}},")
            lines.append("}")
            citations.append("\n".join(lines))

        elif fmt == "ieee":
            author_str = _ieee_authors(authors)
            source = journal_ref or f"arXiv:{arxiv_id}"
            citations.append(f'[{i}] {author_str}, "{title}," {source}, {year}.')

        elif fmt == "mla":
            author_str = _mla_authors(authors)
            source = journal_ref or "arXiv"
            url = f"arxiv.org/abs/{arxiv_id}"
            citations.append(f'{author_str}. "{title}." {source}, {year}, {url}.')

        else:
            author_str = _apa_authors(authors)
            year_str = f"({year})" if year else "(n.d.)"
            source = journal_ref or "arXiv"
            url = f"https://arxiv.org/abs/{arxiv_id}"
            citations.append(f"{author_str} {year_str}. {title}. {source}. {url}")

    return "\n\n".join(citations)


# ─────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────

def _get_year(paper: dict) -> int:
    return int(_extract_year(paper.get("published", "")) or 0)


def _extract_year(published: str) -> str:
    if not published:
        return ""
    try:
        return str(datetime.fromisoformat(published.replace("Z", "+00:00")).year)
    except Exception:
        return published[:4] if len(published) >= 4 else ""


def _compute_relevance(paper: dict, keywords: list[str]) -> float:
    score = 0.0
    title = paper.get("title", "").lower()
    abstract = paper.get("abstract", "").lower()
    for kw in keywords:
        if re.search(rf"\b{re.escape(kw)}\b", title):
            score += 10.0
        elif kw in title:
            score += 5.0
        if re.search(rf"\b{re.escape(kw)}\b", abstract):
            score += 3.0
    year = _get_year(paper)
    if year:
        age = datetime.now(timezone.utc).year - year
        if age <= 1:
            score += 5.0
        elif age <= 3:
            score += 2.0
    return round(score, 2)


def _invert_name(name: str) -> str:
    parts = name.strip().split()
    if len(parts) <= 1:
        return name
    return f"{parts[-1]}, {' '.join(f'{p[0]}.' for p in parts[:-1])}"


def _apa_authors(names) -> str:
    if isinstance(names, str):
        names = [names]
    if not names:
        return "Unknown"
    formatted = [_invert_name(n) for n in names[:20]]
    if len(formatted) == 1:
        return formatted[0]
    if len(formatted) == 2:
        return f"{formatted[0]}, & {formatted[1]}"
    return ", ".join(formatted[:-1]) + f", & {formatted[-1]}"


def _ieee_authors(names) -> str:
    if isinstance(names, str):
        names = [names]
    if not names:
        return "Unknown"
    formatted = []
    for name in names[:6]:
        parts = name.split()
        if len(parts) >= 2:
            initials = " ".join(f"{p[0]}." for p in parts[:-1])
            formatted.append(f"{initials} {parts[-1]}")
        else:
            formatted.append(name)
    if len(names) > 6:
        return formatted[0] + " et al."
    if len(formatted) == 1:
        return formatted[0]
    if len(formatted) == 2:
        return f"{formatted[0]} and {formatted[1]}"
    return ", ".join(formatted[:-1]) + f", and {formatted[-1]}"


def _mla_authors(names) -> str:
    if isinstance(names, str):
        names = [names]
    if not names:
        return "Unknown"
    first = _invert_name(names[0])
    if len(names) == 1:
        return first
    if len(names) == 2:
        return f"{first}, and {names[1]}"
    return f"{first}, et al."


def _bibtex_key(authors, year, title) -> str:
    last_name = "unknown"
    if isinstance(authors, list) and authors:
        last_name = re.sub(r"[^a-z]", "", authors[0].split()[-1].lower())
    title_word = re.sub(r"[^a-z]", "", title.split()[0].lower()) if title else ""
    return f"{last_name}{year}{title_word}"


# ─────────────────────────────────────────────────────────────────────
# Export
# ─────────────────────────────────────────────────────────────────────

ALL_TOOLS = [
    search_arxiv_by_topic,
    search_arxiv_by_author,
    lookup_arxiv_paper,
    filter_and_rank_results,
    format_citations,
]
