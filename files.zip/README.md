# ArXiv Search Agent

**`langgraph.prebuilt.create_react_agent`** + **`langchain_groq.ChatGroq`**

## Quick Start

```bash
pip install -r requirements.txt
cp .env.example .env       # add your GROQ_API_KEY
python main.py
```

## Files (all in one folder — just drop them anywhere)

```
your-folder/
├── main.py              ← python main.py
├── graph.py             ← create_react_agent(ChatGroq, tools)
├── tools.py             ← 5 @tool functions
├── arxiv_client.py      ← arXiv HTTP client
├── models.py            ← Paper, Author dataclasses
├── test_agent.py        ← python test_agent.py
├── requirements.txt
├── .env.example
└── .env                 ← your GROQ_API_KEY
```

## Tests

```bash
python test_agent.py
```
